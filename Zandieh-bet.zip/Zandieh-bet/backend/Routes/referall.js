const express = require('express');
const { authenticateToken } = require('../middleware/auth');
const { getDb } = require('../database');

const router = express.Router();

// دریافت اطلاعات معرفی کاربر
router.get('/info', authenticateToken, async (req, res) => {
    const db = getDb();
    const user = await db.get('SELECT referral_code FROM users WHERE id = ?', req.user.id);
    
    const referrals = await db.all(
        'SELECT username, created_at FROM users WHERE referred_by = ?',
        req.user.id
    );
    
    const commissionSetting = await db.get('SELECT value FROM settings WHERE key = "referral_commission"');
    const commissionRate = parseFloat(commissionSetting.value);
    
    // محاسبه کمیسیون کل (از تراکنش‌های معرفی‌شدگان)
    let totalCommission = 0;
    for (const ref of referrals) {
        const refUser = await db.get('SELECT id FROM users WHERE username = ?', ref.username);
        const earnings = await db.get(
            'SELECT SUM(amount) as total FROM transactions WHERE user_id = ? AND type IN ("faucet", "special_faucet") AND status = "completed"',
            refUser.id
        );
        totalCommission += (earnings.total || 0) * commissionRate;
    }
    
    res.json({
        referral_code: user.referral_code,
        referral_link: `${process.env.SITE_URL}/?ref=${user.referral_code}`,
        referrals_count: referrals.length,
        total_commission: totalCommission,
        referrals_list: referrals
    });
});

// ثبت معرفی هنگام ثبت‌نام (در auth.js باید این منطق اضافه شود)
module.exports = router;