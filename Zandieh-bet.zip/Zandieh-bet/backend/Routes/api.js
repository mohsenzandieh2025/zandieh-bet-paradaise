const express = require('express');
const axios = require('axios');

const router = express.Router();

// دریافت قیمت لحظه‌ای ارزها از CoinGecko
router.get('/prices', async (req, res) => {
    try {
        const response = await axios.get(
            'https://api.coingecko.com/api/v3/simple/price?ids=tron,bitcoin,tether&vs_currencies=usd'
        );
        res.json({
            trx: response.data.tron?.usd || 0,
            btc: response.data.bitcoin?.usd || 0,
            usdt: response.data.tether?.usd || 1
        });
    } catch (error) {
        res.status(500).json({ error: 'خطا در دریافت قیمت‌ها' });
    }
});

// دریافت اطلاعات بلاک‌چین ترون
router.get('/tron/account/:address', async (req, res) => {
    const { address } = req.params;
    try {
        const response = await axios.get(`${process.env.TRON_PROVIDER}/v1/accounts/${address}`);
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: 'خطا در دریافت اطلاعات آدرس ترون' });
    }
});

module.exports = router;