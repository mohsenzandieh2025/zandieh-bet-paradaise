const express = require('express');
const TronWeb = require('tronweb');
const { authenticateToken } = require('../middleware/auth');
const { getDb } = require('../database');

const router = express.Router();

// راه‌اندازی TronWeb
const tronWeb = new TronWeb({
    fullHost: process.env.TRON_PROVIDER,
    privateKey: process.env.TRON_PRIVATE_KEY
});

// دریافت جایزه فاست عادی
router.post('/claim-normal', authenticateToken, async (req, res) => {
    const db = getDb();
    const userId = req.user.id;

    try {
        const user = await db.get('SELECT balance, last_claim FROM users WHERE id = ?', userId);
        const now = new Date();
        const lastClaim = user.last_claim ? new Date(user.last_claim) : null;

        if (lastClaim && (now - lastClaim) < 3600000) {
            const remaining = Math.ceil((3600000 - (now - lastClaim)) / 60000);
            return res.status(429).json({ error: `لطفاً ${remaining} دقیقه دیگر صبر کنید` });
        }

        const settings = await db.get('SELECT value FROM settings WHERE key = "faucet_normal_amount"');
        const rewardAmount = parseFloat(settings.value);

        const newBalance = user.balance + rewardAmount;
        await db.run('UPDATE users SET balance = ?, last_claim = ? WHERE id = ?', newBalance, now.toISOString(), userId);
        await db.run('INSERT INTO transactions (user_id, type, amount, status) VALUES (?, ?, ?, ?)',
            userId, 'faucet', rewardAmount, 'completed');

        // ثبت در لاگ
        res.json({ success: true, amount: rewardAmount, new_balance: newBalance });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'خطا در دریافت جایزه' });
    }
});

// دریافت جایزه ویژه (هر 6 ساعت یک بار)
router.post('/claim-special', authenticateToken, async (req, res) => {
    const db = getDb();
    const userId = req.user.id;

    try {
        const user = await db.get('SELECT balance, last_special_claim FROM users WHERE id = ?', userId);
        const now = new Date();
        const lastSpecial = user.last_special_claim ? new Date(user.last_special_claim) : null;

        if (lastSpecial && (now - lastSpecial) < 21600000) {
            return res.status(429).json({ error: 'جایزه ویژه هر ۶ ساعت یک بار قابل دریافت است' });
        }

        const settings = await db.get('SELECT value FROM settings WHERE key = "faucet_special_min"');
        const settingsMax = await db.get('SELECT value FROM settings WHERE key = "faucet_special_max"');
        const minReward = parseFloat(settings.value);
        const maxReward = parseFloat(settingsMax.value);

        const rewardAmount = minReward + Math.random() * (maxReward - minReward);

        const newBalance = user.balance + rewardAmount;
        await db.run('UPDATE users SET balance = ?, last_special_claim = ? WHERE id = ?', newBalance, now.toISOString(), userId);
        await db.run('INSERT INTO transactions (user_id, type, amount, status) VALUES (?, ?, ?, ?)',
            userId, 'special_faucet', rewardAmount, 'completed');

        res.json({ success: true, amount: rewardAmount, new_balance: newBalance });
    } catch (error) {
        res.status(500).json({ error: 'خطا در دریافت جایزه ویژه' });
    }
});

module.exports = router;