const express = require('express');
const TronWeb = require('tronweb');
const { authenticateToken } = require('../middleware/auth');
const { getDb } = require('../database');

const router = express.Router();
const tronWeb = new TronWeb({ fullHost: process.env.TRON_PROVIDER, privateKey: process.env.TRON_PRIVATE_KEY });

// درخواست برداشت
router.post('/request', authenticateToken, async (req, res) => {
    const { amount, address } = req.body;
    const userId = req.user.id;
    const db = getDb();

    if (!address || !address.startsWith('T')) {
        return res.status(400).json({ error: 'آدرس TRC20 نامعتبر است' });
    }

    const minWithdrawSetting = await db.get('SELECT value FROM settings WHERE key = "min_withdraw"');
    const feeSetting = await db.get('SELECT value FROM settings WHERE key = "withdraw_fee"');
    const minWithdraw = parseFloat(minWithdrawSetting.value);
    const fee = parseFloat(feeSetting.value);

    if (amount < minWithdraw) {
        return res.status(400).json({ error: `حداقل مبلغ برداشت ${minWithdraw} USDT است` });
    }

    const user = await db.get('SELECT balance, trc20_address FROM users WHERE id = ?', userId);
    const totalCost = amount + fee;

    if (user.balance < totalCost) {
        return res.status(400).json({ error: 'موجودی کافی نیست' });
    }

    try {
        // انتقال واقعی USDT (TRC20) - توجه: باید قرارداد USDT را داشته باشید
        const contractAddress = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'; // USDT contract on TRON
        const contract = await tronWeb.contract().at(contractAddress);
        
        const usdtDecimals = 6;
        const amountWithDecimals = amount * Math.pow(10, usdtDecimals);
        
        const transferTx = await contract.transfer(address, amountWithDecimals).send();
        
        // کاهش موجودی کاربر
        const newBalance = user.balance - totalCost;
        await db.run('UPDATE users SET balance = ? WHERE id = ?', newBalance, userId);
        
        // ثبت درخواست برداشت
        await db.run(
            'INSERT INTO withdrawals (user_id, amount, address, tx_hash, status) VALUES (?, ?, ?, ?, ?)',
            userId, amount, address, transferTx, 'completed'
        );
        
        await db.run('INSERT INTO transactions (user_id, type, amount, status, tx_hash) VALUES (?, ?, ?, ?, ?)',
            userId, 'withdraw', -amount, 'completed', transferTx);
        
        res.json({ success: true, tx_hash: transferTx, message: 'برداشت با موفقیت انجام شد' });
    } catch (error) {
        console.error('TRON transfer error:', error);
        res.status(500).json({ error: 'خطا در انجام تراکنش بلاکچین' });
    }
});

// دریافت تاریخچه برداشت‌ها
router.get('/history', authenticateToken, async (req, res) => {
    const db = getDb();
    const withdrawals = await db.all(
        'SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
        req.user.id
    );
    res.json(withdrawals);
});

module.exports = router;