const express = require('express');
const { authenticateToken, isAdmin } = require('../middleware/auth');
const { getDb } = require('../database');

const router = express.Router();

// آمار کلی
router.get('/stats', authenticateToken, isAdmin, async (req, res) => {
    const db = getDb();
    const totalUsers = await db.get('SELECT COUNT(*) as count FROM users');
    const totalWithdrawals = await db.get('SELECT SUM(amount) as total FROM withdrawals WHERE status = "completed"');
    const totalFaucetPaid = await db.get('SELECT SUM(amount) as total FROM transactions WHERE type IN ("faucet", "special_faucet")');
    const pendingWithdrawals = await db.get('SELECT COUNT(*) as count FROM withdrawals WHERE status = "pending"');
    
    res.json({
        total_users: totalUsers.count,
        total_paid: totalFaucetPaid.total || 0,
        total_withdrawn: totalWithdrawals.total || 0,
        pending_withdrawals: pendingWithdrawals.count
    });
});

// دریافت لیست کاربران
router.get('/users', authenticateToken, isAdmin, async (req, res) => {
    const db = getDb();
    const users = await db.all('SELECT id, username, email, balance, created_at, is_admin FROM users ORDER BY balance DESC LIMIT 100');
    res.json(users);
});

// تنظیم نرخ فاست
router.post('/set-faucet-rate', authenticateToken, isAdmin, async (req, res) => {
    const { normal_amount, special_min, special_max } = req.body;
    const db = getDb();
    
    await db.run('UPDATE settings SET value = ? WHERE key = "faucet_normal_amount"', normal_amount);
    await db.run('UPDATE settings SET value = ? WHERE key = "faucet_special_min"', special_min);
    await db.run('UPDATE settings SET value = ? WHERE key = "faucet_special_max"', special_max);
    
    res.json({ success: true });
});

// ارسال اعلان همگانی (در نسخه واقعی می‌توانید به ایمیل/تلگرام متصل کنید)
router.post('/broadcast', authenticateToken, isAdmin, async (req, res) => {
    const { message } = req.body;
    // اینجا می‌توانید به API تلگرام، ایمیل، یا ذخیره در دیتابیس برای نمایش در سایت متصل شوید
    console.log('📢 اعلان همگانی:', message);
    res.json({ success: true, message: 'اعلان ارسال شد' });
});

module.exports = router;