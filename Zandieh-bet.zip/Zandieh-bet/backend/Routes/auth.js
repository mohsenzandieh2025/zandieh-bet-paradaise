const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { getDb } = require('../database');

const router = express.Router();

// ثبت‌نام کاربر جدید
router.post('/register', async (req, res) => {
    const { username, password, email } = req.body;
    const db = getDb();

    if (!username || !password) {
        return res.status(400).json({ error: 'نام کاربری و رمز عبور الزامی است' });
    }

    try {
        const existing = await db.get('SELECT id FROM users WHERE username = ?', username);
        if (existing) {
            return res.status(400).json({ error: 'نام کاربری تکراری است' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const referralCode = 'ZND' + Math.random().toString(36).substring(2, 8).toUpperCase();

        const result = await db.run(
            'INSERT INTO users (username, password, email, referral_code, balance) VALUES (?, ?, ?, ?, ?)',
            username, hashedPassword, email || null, referralCode, 0
        );

        const token = jwt.sign(
            { id: result.lastID, username, is_admin: false },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({ success: true, token, user: { id: result.lastID, username, balance: 0 } });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'خطا در ثبت‌نام' });
    }
});

// ورود کاربر
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const db = getDb();

    try {
        const user = await db.get('SELECT * FROM users WHERE username = ?', username);
        if (!user) {
            return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است' });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ error: 'نام کاربری یا رمز عبور اشتباه است' });
        }

        const token = jwt.sign(
            { id: user.id, username: user.username, is_admin: user.is_admin === 1 },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            token,
            user: {
                id: user.id,
                username: user.username,
                balance: user.balance,
                trc20_address: user.trc20_address,
                referral_code: user.referral_code
            }
        });
    } catch (error) {
        res.status(500).json({ error: 'خطا در ورود' });
    }
});

module.exports = router;