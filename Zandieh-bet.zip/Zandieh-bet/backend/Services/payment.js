// services/paymentService.js
const axios = require('axios');
const crypto = require('crypto');
const ZarinpalCheckout = require('zarinpal-checkout');

class PaymentService {
    constructor() {
        // --- تنظیمات درگاه‌های ایرانی ---
        this.zarinpal = ZarinpalCheckout.create(process.env.ZARINPAL_MERCHANT_ID, process.env.ZARINPAL_CALLBACK_URL, true);
        this.nextpayApiKey = process.env.NEXTPAY_API_KEY;
        this.nextpayCallbackUrl = process.env.NEXTPAY_CALLBACK_URL;

        // --- تنظیمات درگاه‌های رمزارزی ---
        this.nowpaymentsApiKey = process.env.NOWPAYMENTS_API_KEY;
        this.nowpaymentsApiUrl = 'https://api.nowpayments.io/v1';

        // --- تنظیمات Binance Pay ---
        this.binanceApiKey = process.env.BINANCE_PAY_API_KEY;
        this.binanceSecretKey = process.env.BINANCE_PAY_SECRET_KEY;
        this.binanceApiUrl = 'https://bpay.binanceapi.com';
    }

    // 1️⃣ درگاه زرین‌پال (ZarinPal) - ایجاد درخواست پرداخت
    async createZarinpalPayment(amount, description, callbackUrl) {
        try {
            const result = await this.zarinpal.PaymentRequest({
                Amount: amount,
                CallbackURL: callbackUrl || this.zarinpal.callbackUrl,
                Description: description,
                Email: userEmail,
                Mobile: userMobile
            });
            if (result.status === 100) {
                return { success: true, authority: result.authority, paymentUrl: result.url };
            } else {
                return { success: false, error: `Zarinpal error code: ${result.status}` };
            }
        } catch (error) { return { success: false, error: error.message }; }
    }

    // 2️⃣ درگاه نکست‌پی (NextPay) - ایجاد درخواست پرداخت
    async createNextpayPayment(amount, orderId, callbackUrl) {
        try {
            const response = await axios.post('https://api.nextpay.org/gateway/token.json', {
                api_key: this.nextpayApiKey,
                amount: amount,
                order_id: orderId,
                callback_uri: callbackUrl || this.nextpayCallbackUrl
            });
            if (response.data.code === -1) {
                return { success: true, transId: response.data.trans_id, paymentUrl: `https://api.nextpay.org/gateway/payment/${response.data.trans_id}` };
            } else {
                return { success: false, error: `Nextpay error code: ${response.data.code}` };
            }
        } catch (error) { return { success: false, error: error.message }; }
    }

    // 3️⃣ درگاه NOWPayments (رمز ارزها) - ایجاد فاکتور
    async createNowPayment(priceAmount, priceCurrency = 'USD', payCurrency = 'USDT', orderId) {
        try {
            const response = await axios.post(`${this.nowpaymentsApiUrl}/invoice`, {
                price_amount: priceAmount,
                price_currency: priceCurrency,
                pay_currency: payCurrency,
                order_id: orderId,
                ipn_callback_url: `${process.env.SITE_URL}/api/payment/nowpayments-webhook`
            }, { headers: { 'x-api-key': this.nowpaymentsApiKey } });
            return { success: true, invoiceId: response.data.id, paymentUrl: response.data.invoice_url };
        } catch (error) { return { success: false, error: error.message }; }
    }

    // 4️⃣ درگاه Binance Pay - ایجاد سفارش
    async createBinancePayment(amount, currency = 'USDT', orderId) {
        const payload = { env: { terminalType: 'WEB' }, merchantTradeNo: orderId, orderAmount: amount, currency: currency, description: 'Deposit to Zandie Bet Paradise', returnUrl: `${process.env.SITE_URL}/payment/status` };
        const signature = crypto.createHmac('sha512', this.binanceSecretKey).update(Buffer.from(JSON.stringify(payload), 'utf-8')).digest('hex');
        try {
            const response = await axios.post(`${this.binanceApiUrl}/binancepay/openapi/v2/order`, payload, { headers: { 'Content-Type': 'application/json', 'BinancePay-Timestamp': Date.now().toString(), 'BinancePay-Nonce': crypto.randomUUID(), 'BinancePay-Certificate-SN': this.binanceApiKey, 'BinancePay-Signature': signature } });
            if (response.data.status === 'SUCCESS') return { success: true, prepayId: response.data.data.prepayId, checkoutUrl: response.data.data.checkoutUrl };
            else return { success: false, error: response.data.errorMessage };
        } catch (error) { return { success: false, error: error.message }; }
    }

    // 5️⃣ درگاه GembaPay (Stripe + PayPal) - ایجاد سفارش
    async createGembaPayment(amount, currency = 'USD', successUrl, cancelUrl) {
        try {
            const response = await axios.post('https://api.gembapay.com/v1/orders', { amount: amount, currency: currency, success_url: successUrl, cancel_url: cancelUrl, webhook_url: `${process.env.SITE_URL}/api/payment/gemba-webhook` }, { headers: { 'Authorization': `Bearer ${process.env.GEMBAPAY_API_KEY}` } });
            return { success: true, orderId: response.data.id, checkoutUrl: response.data.checkout_url };
        } catch (error) { return { success: false, error: error.message }; }
    }
}
module.exports = new PaymentService();