// services/cryptoService.js
const axios = require('axios');

class CryptoService {
    constructor() {
        // لیست استاتیک ارزهای پشتیبانی شده (نماد، نام، آیکون)
        this.supportedCoins = [
            { symbol: 'BTC', name: 'Bitcoin', icon: '₿', coingeckoId: 'bitcoin', chain: 'BTC' },
            { symbol: 'ETH', name: 'Ethereum', icon: 'Ξ', coingeckoId: 'ethereum', chain: 'ERC20' },
            { symbol: 'USDT', name: 'Tether USD', icon: '₮', coingeckoId: 'tether', chain: 'TRC20' },
            { symbol: 'BNB', name: 'Binance Coin', icon: 'BNB', coingeckoId: 'binancecoin', chain: 'BSC' },
            { symbol: 'XRP', name: 'Ripple', icon: 'XRP', coingeckoId: 'ripple', chain: 'XRP' },
            { symbol: 'DOGE', name: 'Dogecoin', icon: 'Ð', coingeckoId: 'dogecoin', chain: 'DOGE' },
            { symbol: 'SOL', name: 'Solana', icon: '◎', coingeckoId: 'solana', chain: 'SOL' },
            { symbol: 'TRX', name: 'Tron', icon: 'TRX', coingeckoId: 'tron', chain: 'TRX' }
        ];
    }

    async fetchAllPrices() {
        const ids = this.supportedCoins.map(c => c.coingeckoId).join(',');
        try {
            const response = await axios.get(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`);
            return this.supportedCoins.map(coin => ({
                ...coin,
                price_usd: response.data[coin.coingeckoId]?.usd || 0
            }));
        } catch (error) {
            console.error('Error fetching prices:', error);
            return this.supportedCoins.map(coin => ({ ...coin, price_usd: 0 }));
        }
    }
}
module.exports = new CryptoService();