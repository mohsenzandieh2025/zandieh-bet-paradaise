require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const rateLimit = require('express-rate-limit');
const { initializeDatabase } = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Rate limiting برای جلوگیری از اسپم
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 دقیقه
    max: 100,
    message: { error: 'درخواست太多، لطفاً کمی صبر کنید' }
});
app.use('/api/', limiter);

// راه‌اندازی دیتابیس
let db;
initializeDatabase().then(database => {
    db = database;
    console.log('✅ دیتابیس SQLite راه‌اندازی شد');
});

// ایمپورت روت‌ها
const authRoutes = require('./routes/auth');
const faucetRoutes = require('./routes/faucet');
const walletRoutes = require('./routes/wallet');
const withdrawRoutes = require('./routes/withdraw');
const referralRoutes = require('./routes/referral');
const tasksRoutes = require('./routes/tasks');
const leaderboardRoutes = require('./routes/leaderboard');
const adminRoutes = require('./routes/admin');
const apiRoutes = require('./routes/api');

// استفاده از روت‌ها
app.use('/api/auth', authRoutes);
app.use('/api/faucet', faucetRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/withdraw', withdrawRoutes);
app.use('/api/referral', referralRoutes);
app.use('/api/tasks', tasksRoutes);
app.use('/api/leaderboard', leaderboardRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', apiRoutes);

// روت اصلی
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🚀 سرور زندیه بت پارادایس روی پورت ${PORT} اجرا شد`);
});