const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');

let db;

async function initializeDatabase() {
    db = await open({
        filename: path.join(__dirname, 'database', 'zandie.sqlite'),
        driver: sqlite3.Database
    });

    // ایجاد جداول
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT,
            trc20_address TEXT,
            balance REAL DEFAULT 0,
            referral_code TEXT UNIQUE,
            referred_by INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_claim DATETIME,
            total_claimed REAL DEFAULT 0,
            is_admin INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            type TEXT,
            amount REAL,
            status TEXT,
            tx_hash TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS withdrawals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount REAL,
            address TEXT,
            tx_hash TEXT,
            status TEXT DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            task_name TEXT,
            completed_at DATETIME,
            reward REAL,
            UNIQUE(user_id, task_name)
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
    `);

    // تنظیمات پیش‌فرض
    await db.run(`INSERT OR IGNORE INTO settings (key, value) VALUES 
        ('faucet_normal_amount', '0.45'),
        ('faucet_special_min', '1'),
        ('faucet_special_max', '5'),
        ('min_withdraw', '2'),
        ('withdraw_fee', '0.5'),
        ('referral_commission', '0.25'),
        ('daily_bonus_enabled', '1')
    `);

    return db;
}

function getDb() {
    return db;
}

module.exports = { initializeDatabase, getDb };